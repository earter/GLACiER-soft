var searchData=
[
  ['frame_5flength_5fextended',['FRAME_LENGTH_EXTENDED',['../classDW1000Class.html#a6f4250f4cc8a7f38293d60e3e1a722b6',1,'DW1000Class']]],
  ['frame_5flength_5fnormal',['FRAME_LENGTH_NORMAL',['../classDW1000Class.html#a378b455a17d93d4de91cdb6e237e217b',1,'DW1000Class']]]
];
